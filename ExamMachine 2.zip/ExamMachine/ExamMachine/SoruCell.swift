//
//  SoruCell.swift
//  ExamMachine
//
//  Created by Mac on 25.09.2020.
//  Copyright © 2020 Mac. All rights reserved.
//

import UIKit

class SoruCell: UITableViewCell {


    @IBOutlet weak var lblSoruDegeri: UILabel!
    @IBOutlet weak var lblXP: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
