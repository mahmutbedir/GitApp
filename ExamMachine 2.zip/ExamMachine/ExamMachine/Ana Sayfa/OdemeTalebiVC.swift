//
//  OdemeTalebiVC.swift
//  ExamMachine
//
//  Created by Mac on 10.10.2020.
//  Copyright © 2020 Mac. All rights reserved.
//

import UIKit
import Parse

class OdemeTalebiVC: UIViewController {

    @IBOutlet weak var txtisimSoyisim: UITextField!
    @IBOutlet weak var txtBankaAdi: UITextField!
    @IBOutlet weak var txtIban: UITextField!
    @IBOutlet weak var txtCekilecekTutar: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    @IBAction func btnParaTalebi(_ sender: Any) {
        if txtisimSoyisim.text != "" && txtBankaAdi.text != "" && txtIban.text != "" && txtCekilecekTutar.text != "" {

            let odemeTalebi = PFObject(className: "OdemeTalepleri")
            odemeTalebi["UserId"] = PFUser.current()
            odemeTalebi["UserAdSoyad"] = txtisimSoyisim.text!
            odemeTalebi["BankaAdi"] = txtBankaAdi.text!
            odemeTalebi["IBAN"] = txtIban.text!
            odemeTalebi["Tutar"] = txtCekilecekTutar.text!
            
            var rnd = randomString(5)
            odemeTalebi["KayitNo"] = rnd

            odemeTalebi.saveInBackground { (success, error) in
                if error != nil{
                    self.makeAlert(titleInput: "Error", messageInput: error?.localizedDescription ?? "Talep oluşturma hatası!")
                } else {
                    print("OK")
                    self.dismiss(animated: true, completion: nil)
                }
            }
            
        } else {
            makeAlert(titleInput: "Hata", messageInput: "Banka / IBAN / Tutar ??")
        }
    }
    
    func makeAlert(titleInput : String, messageInput: String) {
        let alert = UIAlertController(title: titleInput, message: messageInput, preferredStyle: .alert)
        let okButton = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okButton)
        self.present(alert, animated: true, completion: nil)
    }
    
    func randomString(_ n: Int) -> String
    {
        let digits = "ABCDEF1234567890"
        var result = ""

        for _ in 0..<n {
            result += String(digits.randomElement()!)
        }

        return result
    }
}
