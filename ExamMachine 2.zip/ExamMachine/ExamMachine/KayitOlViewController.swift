//
//  KayitOlViewController.swift
//  ExamMachine
//
//  Created by Mac on 23.09.2020.
//  Copyright © 2020 Mac. All rights reserved.
//

import UIKit
import Parse

class KayitOlViewController: UIViewController {

    
    @IBOutlet weak var txtAdSoyad: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtTel: UITextField!
    @IBOutlet weak var txtPass: UITextField!
    @IBOutlet weak var txtPassTekrar: UITextField!
    @IBOutlet weak var txtReferans: UITextField!
    @IBOutlet weak var segCinsiyet: UISegmentedControl!
    
    var refKodu = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBAction func btnKayitOlClicked(_ sender: Any) {
        
        if txtEmail.text != "" && txtPass.text != "" && txtAdSoyad.text != "" && txtPassTekrar.text != "" {

            let user = PFUser()
            user.email = txtEmail.text!
            user.username = txtAdSoyad.text!
            
            if txtPass.text != txtPassTekrar.text {
                makeAlert(titleInput: "Error", messageInput: "Şifreler uyuşmuyor!")
                return
            } else {
                user.password = txtPass.text!
            }
            if let ref = txtReferans.text {
                user["Referansim"] = ref
                refKodu = ref
            }
            if segCinsiyet.selectedSegmentIndex == 0 {
                user["Cinsiyet"] = 0
            } else {
                user["Cinsiyet"] = 1
            }
            
            var rnd = randomString(8)
            user["ReferansKodum"] = rnd
            
            
            
            user.signUpInBackground { (success, error) in
                if error != nil{
                    self.makeAlert(titleInput: "Error", messageInput: error?.localizedDescription ?? "Error!")
                } else {
                    print("OK")
                    self.referansiArtir()
                    self.performSegue(withIdentifier: "toFeedVC", sender: nil)
                }
            }
            
        } else {
            makeAlert(titleInput: "Error", messageInput: "Ad Soyad / Email / Şifre ??")
        }
        
    }
    
    func makeAlert(titleInput : String, messageInput: String) {
        let alert = UIAlertController(title: titleInput, message: messageInput, preferredStyle: .alert)
        let okButton = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okButton)
        self.present(alert, animated: true, completion: nil)
    }
    
    func referansiArtir() {
        
        let query = PFQuery(className: "_User")
        query.whereKey("ReferansKodum", equalTo: String(refKodu) )
        
        query.findObjectsInBackground { (objects, error) in
            if error != nil {

            } else {
                for object in objects! {
                    var us = (object) as! PFUser
                    us.objectId = object.objectId
                    us.incrementKey("ReferansSayim", byAmount: NSNumber(value : 1.00))
                    us.saveInBackground { (success, error) in
                        if error != nil {
                            self.makeAlert(titleInput: "Error", messageInput: error?.localizedDescription ?? "Hata Kodu 2000")
                        } else {
                            print("success")
                        }
                    }
                }

            }
        }
    }
    
    func randomString(_ n: Int) -> String
    {
        let digits = "ABCDEF1234567890"
        var result = ""

        for _ in 0..<n {
            result += String(digits.randomElement()!)
        }

        return result
    }
    
}
