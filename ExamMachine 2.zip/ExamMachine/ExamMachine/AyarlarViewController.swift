//
//  AyarlarViewController.swift
//  ExamMachine
//
//  Created by Mac on 23.09.2020.
//  Copyright © 2020 Mac. All rights reserved.
//

import UIKit
import Parse
import GoogleMobileAds

class AyarlarViewController: UIViewController {

    var interstitial: GADInterstitial!

    override func viewDidLoad() {
        super.viewDidLoad()
        interstitial = GADInterstitial(adUnitID: "ca-app-pub-3940256099942544/4411468910")
        let request = GADRequest()
        interstitial.load(request)
    }
    

    @IBAction func CikisYapClicked(_ sender: Any) {
        
        PFUser.logOutInBackground { (error) in
            if error != nil
            {
                self.makeAlert(titleInput: "Error", messageInput: error?.localizedDescription ?? "Logout hatası.")
            }
            else{
                self.performSegue(withIdentifier: "toGirisYapController", sender: nil)
            }
        }
    }
    
    @IBAction func btnSoruEkle(_ sender: Any) {
        if interstitial.isReady {
          interstitial.present(fromRootViewController: self)
        } else {
          print("Ad wasn't ready")
        }

        performSegue(withIdentifier: "toSoruEkle", sender: nil)
    }
    
    func makeAlert(titleInput : String, messageInput: String) {
        let alert = UIAlertController(title: titleInput, message: messageInput, preferredStyle: .alert)
        let okButton = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okButton)
        self.present(alert, animated: true, completion: nil)
    }
}
