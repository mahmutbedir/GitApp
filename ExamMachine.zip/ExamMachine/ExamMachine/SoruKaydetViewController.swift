//
//  SoruKaydetViewController.swift
//  ExamMachine
//
//  Created by Mac on 24.09.2020.
//  Copyright © 2020 Mac. All rights reserved.
//

import UIKit
import Parse

class SoruKaydetViewController: UIViewController {

    @IBOutlet weak var txtSoru: UITextField!
    @IBOutlet weak var txtA: UITextField!
    @IBOutlet weak var txtB: UITextField!
    @IBOutlet weak var txtC: UITextField!
    @IBOutlet weak var txtD: UITextField!
    @IBOutlet weak var txtDogruCevap: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    @IBAction func btnKaydet(_ sender: Any) {
        
        let object = PFObject(className: "Sorular")
        object["Soru"] = txtSoru.text!
        object["A"] = txtA.text!
        object["B"] = txtB.text!
        object["C"] = txtC.text!
        object["D"] = txtD.text!
        
        object.saveInBackground { (success, error) in
            if error != nil {
                
            } else {
                self.performSegue(withIdentifier: "toAyarlaraDon", sender: nil)
            }
        }
    }
    
}
