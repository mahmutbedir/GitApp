//
//  KayitOlViewController.swift
//  ExamMachine
//
//  Created by Mac on 23.09.2020.
//  Copyright © 2020 Mac. All rights reserved.
//

import UIKit
import Parse

class KayitOlViewController: UIViewController {

    
    @IBOutlet weak var txtAdSoyad: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtTel: UITextField!
    @IBOutlet weak var txtPass: UITextField!
    @IBOutlet weak var txtPassTekrar: UITextField!
    @IBOutlet weak var txtReferans: UITextField!
    @IBOutlet weak var segCinsiyet: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBAction func btnKayitOlClicked(_ sender: Any) {
        
        if txtEmail.text != "" && txtPass.text != "" && txtAdSoyad.text != "" && txtPassTekrar.text != "" {

            let user = PFUser()
            user.email = txtEmail.text!
            user.username = txtAdSoyad.text!
            user.password = txtPass.text!
            
            user.signUpInBackground { (success, error) in
                if error != nil{
                    self.makeAlert(titleInput: "Error", messageInput: error?.localizedDescription ?? "Error!")
                } else {
                    print("OK")
                    self.performSegue(withIdentifier: "toFeedVC", sender: nil)
                }
            }
            
        } else {
            makeAlert(titleInput: "Error", messageInput: "Ad Soyad / Email / Şifre ??")
        }
        
    }
    
    func makeAlert(titleInput : String, messageInput: String) {
        let alert = UIAlertController(title: titleInput, message: messageInput, preferredStyle: .alert)
        let okButton = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okButton)
        self.present(alert, animated: true, completion: nil)
    }
    
}
