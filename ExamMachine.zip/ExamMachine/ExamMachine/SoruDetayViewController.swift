//
//  SoruDetayViewController.swift
//  ExamMachine
//
//  Created by Mac on 24.09.2020.
//  Copyright © 2020 Mac. All rights reserved.
//

import UIKit
import Parse

class SoruDetayViewController: UIViewController {

    @IBOutlet weak var lblSoru: UILabel!
    @IBOutlet weak var btnA: UIButton!
    @IBOutlet weak var btnB: UIButton!
    @IBOutlet weak var btnC: UIButton!
    @IBOutlet weak var btnD: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    



}
