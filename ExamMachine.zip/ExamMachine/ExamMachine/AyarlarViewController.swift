//
//  AyarlarViewController.swift
//  ExamMachine
//
//  Created by Mac on 23.09.2020.
//  Copyright © 2020 Mac. All rights reserved.
//

import UIKit
import Parse

class AyarlarViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    @IBAction func CikisYapClicked(_ sender: Any) {
        
        PFUser.logOutInBackground { (error) in
            if error != nil
            {
                self.makeAlert(titleInput: "Error", messageInput: error?.localizedDescription ?? "Logout hatası.")
            }
            else{
                self.performSegue(withIdentifier: "toGirisYapController", sender: nil)
            }
        }
    }
    
    @IBAction func btnSoruEkle(_ sender: Any) {
        performSegue(withIdentifier: "toSoruEkle", sender: nil)
    }
    
    func makeAlert(titleInput : String, messageInput: String) {
        let alert = UIAlertController(title: titleInput, message: messageInput, preferredStyle: .alert)
        let okButton = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okButton)
        self.present(alert, animated: true, completion: nil)
    }
}
